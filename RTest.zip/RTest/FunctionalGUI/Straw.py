#inf_low_limit = 1000.0
#ii_pass_range = [150.0,250.0]
#oo_pass_range = [50.0,150.0]
ii_pass_range = [10,10000]
oo_pass_range = [10,10000]
inf_low_limit = 10

class Straw:
    def __init__(self):
        self.V5 = None #should always be 5 volts
        self.measurements = [] #the 4 unaltered Arduino measurements
        self.r2 = None #one number
        self.devRes = [] #the device resistance associated with every measurement
        self.perErr = [] #the % error for each measurement
        self.finalMeas = [] #the actual resistance value
        self.tempBool = [] #the status of each measurement
        self.status = False
        self.string = ""

    def setCalibInfo(self,V5,r2):
        self.V5 = float(V5)
        self.r2 = float(r2)

    def appendDevResistance(self,devResist,perE):
        self.devRes.append(float(devResist))
        self.perErr.append(float(perE))

    def appendMeasurement(self,data):
        self.measurements.append(float(data))
        
    def calibrateData(self):
        intermediate = []
        resistNum = []
        for el in self.measurements:
            dData = None
            dData = el * self.V5 / 1023
            intermediate.append(dData)
        for el in intermediate:
            if el != 0:
                data = None
                data = self.r2 * (self.V5 - el) / el
                resistNum.append(data)
            else:
                resistNum.append(1000000)
        for i in range(len(resistNum)):
            final = []
            final = (resistNum[i] / (1 - self.perErr[i])) - self.devRes[i]
            self.finalMeas.append(final)

    def detStatus(self):
        self.tempBool = []
        self.string = ""
        if ii_pass_range[0] <= self.finalMeas[0] <= ii_pass_range[1]:
            self.tempBool.append(True)
            self.string += "ii: " + str(self.finalMeas[0])[:7] + '\n'
        else:
            self.tempBool.append(False)
            self.string += "ii: " + str(self.finalMeas[0])[:7] + '\n'

        if self.finalMeas[1] > inf_low_limit:
            self.tempBool.append(True)
            self.string += 'io: ' + 'Infinite' + '\n'

        else:
            self.tempBool.append(False)
            self.string += 'io: ' + str(self.finalMeas[1])[:7] + '\n'

        if self.finalMeas[2] > inf_low_limit:
            self.tempBool.append(True)
            self.string += 'oi: ' + 'Infinite' + '\n'

        else:
            self.tempBool.append(False)
            self.string += 'oi: ' + str(self.finalMeas[2])[:7] + '\n'

        if oo_pass_range[0] <= self.finalMeas[3] <= oo_pass_range[1]:
            self.tempBool.append(True)
            self.string += 'oo: ' + str(self.finalMeas[3])[:7] + '\n'

        else:
            self.tempBool.append(False)
            self.string += 'oo: ' + str(self.finalMeas[3])[:7] + '\n'

        if False in self.tempBool:
            None
        else:
            self.status = True

    def printData(self): #for debugging
        print(self.V5)
        print('-------------------------')
        print(self.measurements)
        print('-------------------------')
        print(self.r2)
        print('-------------------------')
        print(self.devRes)
        print('-------------------------')
        print(self.perErr)
        print('-------------------------')
        print(self.finalMeas)

    def failedFormat(self):
        returnMe = []
        dummy = ['inside-inside','inside-outside','outside-inside','outside-outside']
        tempData = [el for el in self.finalMeas]
        for i in range(4):
            if tempData[i] > inf_low_limit:
                tempData[i] = 'Inf'
        for i in range(4):
            returnMe.append(tempData[i])
            returnMe.append(dummy[i])
            returnMe.append(self.tempBool[i])

        return returnMe


    def saveFormat(self):
        if not self.status:
            return False
        returnMe = []
        tempData = [el for el in self.finalMeas]
        dummy = ['inside-inside','inside-outside','outside-inside','outside-outside']
        for i in range(4):
            if tempData[i] > inf_low_limit:
                tempData[i] = 'Inf'
        for i in range(4):
            returnMe.append(tempData[i])
            returnMe.append(dummy[i])
            returnMe.append(self.tempBool[i])

        return returnMe
        














        
