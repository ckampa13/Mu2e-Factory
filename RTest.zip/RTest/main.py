import sys
from PyQt5 import QtCore,QtGui,QtWidgets
from PyQt5.QtGui import QPixmap
from properties import Ui_Dialog
import resistance
from datetime import datetime
import time

class CompletionTrack(QtWidgets.QDialog):
    def __init__(self):
        super().__init__() 
        self.ui = Ui_Dialog()
        self.ui.setupUi(self)
        self.show()
        self.text = [self.ui.text1,self.ui.text2,self.ui.text3,self.ui.text4,self.ui.text5,self.ui.text6,self.ui.text7,self.ui.text8,self.ui.text9,self.ui.text10,self.ui.text11,self.ui.text12,self.ui.text13,self.ui.text14,self.ui.text15,self.ui.text16,self.ui.text17,self.ui.text18,self.ui.text19,self.ui.text20,self.ui.text21,self.ui.text22,self.ui.text23,self.ui.text24]
        self.led = [self.ui.led1,self.ui.led2,self.ui.led3,self.ui.led4,self.ui.led5,self.ui.led6,self.ui.led7,self.ui.led8,self.ui.led9,self.ui.led10,self.ui.led11,self.ui.led12,self.ui.led13,self.ui.led14,self.ui.led15,self.ui.led16,self.ui.led17,self.ui.led18,self.ui.led19,self.ui.led20,self.ui.led21,self.ui.led22,self.ui.led23,self.ui.led24]
        self.box = [self.ui.st1,self.ui.st2,self.ui.st3,self.ui.st4,self.ui.st5,self.ui.st6,self.ui.st7,self.ui.st8,self.ui.st9,self.ui.st10,self.ui.st11,self.ui.st12,self.ui.st13,self.ui.st14,self.ui.st15,self.ui.st16,self.ui.st17,self.ui.st18,self.ui.st19,self.ui.st20,self.ui.st21,self.ui.st22,self.ui.st23,self.ui.st24]
        self.initialize()
        self.ui.generatebutton.clicked.connect(self.collectData)
        self.ui.resetButton.clicked.connect(self.reset)
        self.string_list =[]
        self.old_string = []
        self.DATA = []
        self.oldDATA = []
        self.dataGetter = None
        self.lastMeasure = None
        self.strawNumbers = []

    def reset(self):
        if self.ui.strawbox.text():
            self.saveData()
        self.ui.workerIDbox.setText("")
        self.ui.workStationbox.setText("")
        self.ui.strawbox.setText("")
        self.oldDATA = []
        self.old_string = []
        for el in self.box:
            el.setText('Straw#')
        for el in self.text:
            el.setText("")
        try:
            self.LEDreset()
        except:
            print("Understandable, have a nice day")
            
    def collectData(self):
        worker = str(self.ui.workerIDbox.text())
        workstation = str(self.ui.workStationbox.text())
        straw = self.ui.strawbox.text()
        if not worker and not workstation and not straw:
            self.error(False)
            return
        self.dataGetter = resistance.Resistance(worker,workstation,straw)
        self.assignNumbers(straw)
        self.lastMeasure = straw
        try:
            self.DATA, self.string_list = self.dataGetter.rMain()
        except:
            print("Arduino Error")
            self.error(False)
            return
        self.combineDATA()
        try:
            self.updateLights()
        except:
            print("Lights Broke")
            self.error(False)
            return
        self.oldDATA = self.DATA
        self.old_string = self.string_list
        self.error(True)


    def assignNumbers(self,straw): #takes the first straw numbers and assigns straw numbers to the remaining straws
        #assumes the straws are sequential~
        #this function works 100%
        initial = straw
        st = initial[0:2]
        new = initial[2:7]
        char_find = None
        for i in range(5): #splits the leading zeros from the numbers that matter
            if new[i] != "0":
                char_find = i
                break
        st = st + new[0:char_find]
        first = new[char_find:]
        first = int(first)
        self.strawNumbers = []
        arbitrary_counter = 0
        while arbitrary_counter < 24: #makes the inital box values
            self.strawNumbers.append(st+str(first+arbitrary_counter))
            arbitrary_counter += 1
        s = self.strawNumbers
        for ite in range(len(s)): #makes sure the number has a length of 5
            if len(s[ite]) > 7:
                p1 = s[ite][0:2]
                p2 = s[ite][3:8]
                s[ite] = p1+p2
        for i in range(24):
            self.box[i].setText(s[i])
            
    def updateLights(self):
        for i in range(24):
            self.LEDchange(self.DATA[i],self.led[i])
            self.text[i].setText(self.string_list[i])
        
        
        
        
    def LEDreset(self):
        for el in self.led:
            el.setPixmap(QPixmap('white.png'))
        self.ui.error.setPixmap(QPixmap("white.png"))
            
    def LEDchange(self,data,led):
        failed = QPixmap("red.png")
        passed = QPixmap("green.png")
        reset = QPixmap("white.png")
        if data:
            led.setPixmap(passed)
        else:
            led.setPixmap(failed)

    def initialize(self):
        default = QPixmap("white.png")
        logo = QPixmap("mu2e.jpg")
        for i in range(24):
            self.led[i].setPixmap(default)
        self.ui.mu2e.setPixmap(logo)
        self.ui.error.setPixmap(default)

    def combineDATA(self):
        if not self.oldDATA:
            None
        else: 
            for i in range(24):
               if self.oldDATA[i]:
                    self.DATA[i] = self.oldDATA[i]
                    self.string_list[i] = self.old_string[i]

    def error(self,boo):
        failed = QPixmap("red.png")
        passed = QPixmap("green.png")
        if not boo:
            disp = failed
        else:
            disp = passed
        self.ui.error.setPixmap(disp)

    def saveData(self):
        final = 'Straw Number, Timestamp, Worker ID, Workstation ID, Resistance(Ohms), Temp(F), Humidity(%), Measurement Type, Pass/Fail \n' 
        data = self.dataGetter.saveStraws()
        day = datetime.now().strftime("%Y-%m-%d_%H%M%S_")
        first = self.strawNumbers[0]
        last = self.strawNumbers[23]
        fileName = 'StrawResistance_' + day + '_' + first + '-' + last + '.csv' 
        print(fileName)
        for i in range(24):
            straw = self.strawNumbers[i]
            for i in range(4):
                final += straw + ', ' + data.pop(0) + '\n'
        save = open(fileName,'w+')
        save.write(final)
        save.close()
            
        
                
            

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    ctr = CompletionTrack()
    ctr.show()
    sys.exit(app.exec_())
    
