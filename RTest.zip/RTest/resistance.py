import serial
from datetime import datetime
import time
import csv
import os
import colorama
from colorama import Back
from Straw import Straw
import sys


#
#   Author:    Cole Kampa and Zach Riehl
#   Email: <kampa041@umn.edu> , <riehl046@umn.edu>
#   Institution: University of Minnesota
#   Project: Mu2e
#   Date: 3/1/2018
#   Most Recent Update: 2018
#   
#   Description: 
#       A Python3 script using PySerial to control and read from an Arduino Uno and PCB connected to a 
#       full pallet of straws. Returns the data in the in order to be displayed by the packaged GUI.
#
#   Columns in file (for database): straw_barcode, create_time, worker_barcode, workstation_barcode,
#       resistance, temperature, humidity, test_type, pass/fail
#
#   Packages: PySerial, colorama, Straw (custom wrapper class)
#
#   General Order: arbrcrdrerfrgrhrirjrkrlrmrnrorpr
#
#   Adjusted Order: 1)erfrgrhr 2)arbrcrdr 3)mrnrorpr 4)irjrkrlr
#



#os.system('mode con: cols=115 lines=50')
com = '/dev/ttyACM0'

calibFile = "calib.csv"
dataFile = None
measLet = 'abcdefghijklmnop'

average = 'average'

try:
    cereal = serial.Serial(com, 9600,timeout=10)
    print(cereal.readline().decode('utf-8').rstrip())
except:
    print("No Arduino Connected")
    sys.exit()

class Resistance:
    def __init__(self, worker, workstation, first_straw, temp = 73.4, humidity = 45):
        self.average = average
        self.worker = worker
        self.workstation = workstation
        self.iStraw = first_straw
        self.temp = temp
        self.humidity = humidity
        self.strawList = [Straw() for i in range(24)]
        self.boolList = []
        self.string_list = []

    def rMain(self):
        colorama.init()
        self.getCalibrationData()
        self.setAverage()
        self.getMeasurements()
        for el in self.strawList:
            el.calibrateData()
            el.detStatus()
            self.boolList.append(el.status)
            self.string_list.append(el.string)
##            print(el.finalMeas)
        colorama.deinit()
##        print(self.boolList)
##        print(self.string_list)
        return self.boolList, self.string_list

    def setAverage(self):
        cereal.write(b'y')
        

    def getCalibrationData(self):
        #stores the calib data for each straw within its class
        r2_List = []
        V5 = 0
        Vin = 0
        with open(calibFile) as csvf:
            csvReader = csv.reader(csvf)
            lineCount = 0
            index = 0
            loop = True
            while loop:
                try:
                    text = csvReader.__next__()
                    if lineCount == 1:
                        Vin = float(text[0])
                        V5 = float(text[1])
                    elif lineCount == 3:
                        for el in text:
                            r2_List.append(float(el))
                    elif lineCount > 4:
                        if lineCount % 4 == 1:
                            self.strawList[index].setCalibInfo(V5,r2_List[index//4])
                        self.strawList[index].appendDevResistance(float(text[2]),float(text[1]))
                        if lineCount % 4 == 0:
                            index += 1
                except:
                    loop = False
                lineCount += 1
                        
    def getMeasurements(self):
        indexList = [[0,4,8,12,16,20],[1,5,9,13,17,21],[2,6,10,14,18,22],[3,7,11,15,19,23]]
        measNum = 1
        index = 0
        for char in measLet:
            appendList = indexList[index]
            cereal.write(bytes(char + 'r', 'ascii'))
            rawData = cereal.readline().decode('utf-8').rstrip().split(',')
            if rawData[0] != char:
                return False
            del rawData[0]
            for i in range(len(rawData)):
                strNum = appendList[i]
                self.strawList[strNum].appendMeasurement(rawData[i])
            if measNum % 4 == 0:
                index += 1
            measNum += 1

    def saveStraws(self):
        returnMe = []
        time = datetime.now().strftime("%Y/%m/%d %H:%M:%S")
        for s in self.strawList:
            temp = s.saveFormat()
            for i in range(4):
                num = str(temp.pop(0))
                meas = temp.pop(0)
                stat = 'fail'
                if temp.pop(0):
                    stat = 'pass'
                string = time + ', ' + self.worker + ', ' + self.workstation + ', ' + num + ', ' + str(self.temp) + ', ' + str(self.humidity) + ', ' + meas + ', ' + stat
                returnMe.append(string)

        return returnMe                
            
                
                
    



